# Writing investigation records

Read this when authoring cards, Current State or handovers. Keep the main
skill's operator-facing answer rules; these are the record-specific details.

## Provenance and attachments

Keep authenticated principal, collector, message author, original reporter,
relay chain and requester separate. Preserve known source references and roles;
separate messages with different source chains. A source profile describes a
reported source, not a connection or proof that a query ran there.

Upload supplied file bytes with `artifact_put`, then use returned artifact IDs.
MCP accepts bytes, not local paths. Check size limits; use an authorized CLI
upload if needed. Do not fetch unrelated files just to complete metadata.

Choose classifications deliberately: `symptom`, `possible_cause` (Suspected),
`confirmed` or `unrelated`. Legacy `rejected` remains readable and reversible.
Unrelated requires a reason about this investigation; it does not falsify source
evidence. Confirmation needs support, mechanism, scope and remaining uncertainty.

Preserve optional `improvement` fields (`kind: toil|cleanup`, `next_action`,
credential-free HTTP(S) `external_url`). Metadata search pairs `metadata_key`
and `metadata_value`; improvement filters apply to the same exact record.

## Card text

Use short, single-line plain-text titles or statements, usually 4–10 words.
Lead with component and deviation; keep uncertainty in suspected-cause headings.
Synthetic example: "Quartz API: median latency reached 240 ms".

Put the observation in evidence `summary`, original material and queries in
`raw_text`/`operations`, supporting detail in finding `rationale`, and mechanism,
scope, tests and uncertainty in `assessment`. Put provenance in `source`,
`report`, `references` and exact `evidence_relations`. Lead with a date or ticket
only when needed to distinguish observations. Keep details accessible in full;
do not assume the UI collapses long text.

When shortening headings, retain detail in body fields. Preserve classification,
critical flags, received text and uncertainty. Review the new evidence revision
before deliberately updating a finding's exact link, even after a title edit;
never silently retarget an assessment across substantive evidence changes.

Keep useful failed attempts, execution context and coverage in evidence
`operations`; this is a payload field, not a journal tool. Plans belong in
assessment or next steps. Label separate preregistered tests as plans.

For repeated alerts and mutable sources, use [reporting examples](reporting.md).
Record the observation and known filters, bounds, timezone, source/version and
response behind a URL. A link does not freeze data or reproduce alert evaluation.
Separate notifications, unique incidents and recovery; deduplicate only by
supported source identities and label partial coverage.

## Code layout

Use Markdown fences for logs or code inside longer prose, with a known language
or `text`. Preserve literal indentation, blank and long lines; put fences on their
own lines and use a longer outer fence for content containing backticks. Existing
operation/result fields already display literally and need no added fences.
Do not rewrite received evidence for formatting. Language tags do not establish
execution or authenticity. See [request examples](request-examples.md) if needed.

## Current State and handovers

A requested State refresh synthesizes the facts and next actions needed to resume
work. Avoid repeating detail across facts, causes and uncertainty. Remove answered
checks from active next steps while preserving history, unrelated work, exact
references and freshness. A narrow append preserves the rest of State; a State
refresh alone does not authorize finding revisions. Follow
[tool operations](tool-operations.md) for reviewed basis and concurrency.

An audience report uses `base_handover_id` and claims supported by that snapshot.
Later evidence belongs in a new snapshot. Report observed recovery separately
from cause, and preserve unknown impact and ETA. Show what was tried and its
outcomes. Return references after the useful conclusion, never a raw card dump.

Reusable examples must be independently invented and labeled synthetic. Renaming
real cases while retaining measurements, identifiers or distinctive sequences
is insufficient. Never present synthetic material as collected evidence.
