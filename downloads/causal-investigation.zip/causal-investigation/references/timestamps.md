# Evidence times and incident timing

Read the live schema. Evidence occurrence and observation fields belong directly in
`evidence_submit.body`, inside `capture_submit.body.evidence`, or in the revised
evidence payload. Findings link exact evidence revisions; they do not supply an
independent occurrence timestamp. Author-reported incident boundaries belong on
the investigation, as described below.

## Contents

- Record event and observation times before saving
- Incident start and recovery
- Known local time
- Message time without occurrence time
- Reports containing several events
- Corrections and verification

## Record event and observation times before saving

For every `evidence_submit`, `capture_submit` and `evidence_revise`, inspect the
supplied material for when the event happened, when someone observed it, and when
it was reported. Record each supported time in its own field; do not leave known
times only in prose or fill unknown times with the current time. The dated
observation in Timeline comes from evidence occurrence fields; a finding or
Current State update alone does not create it.

1. Set `event_time_start` when the source supports an occurrence time. Use
   `event_time_end` for a supported range. Resolve to RFC 3339 UTC ending in `Z`;
   preserve `original_time_text` and the known IANA `original_timezone`.
2. Set `time_precision` deliberately: `exact`, `approximate`, `interval` or
   `unknown`. Preserve the source's precision; do not turn "around 19:41" into
   an exact onset or invent a duration. Use date-only bounds only as an explicitly
   labeled calendar window, never as a measured incident duration.
3. Set `observed_at` when the source reports an observation time or the collector
   records it while directly observing the source. Keep it separate from
   `report.sent_at` (when communicated), occurrence time and server-owned
   registration time. Do not copy one to another without a supported basis. If
   observation time is unknown, leave it unknown rather than substituting
   collection or registration time.
4. Resolve clock-only or relative dates from explicit source context or the user's
   answer. Ask for a missing date or timezone when it prevents resolution. Reuse
   that answer within its stated scope; do not infer from the machine's timezone.
   Preserve unresolved text, use null occurrence fields and `unknown`, and state
   the missing context in `limitations` if saving before clarification.
5. Read back `observed_at`, occurrence fields and `timeline_list` ordered by
   `event_time`. Follow pages to locate the saved revision. Compare each time
   with its source, including explicit unknowns. Repair omitted or incorrect
   times with `evidence_revise`, then read back again. Finish only when supported
   times match, or report what remains unverified; preserve concurrency rules.


## Incident start and recovery

Use this workflow when asked to record or correct an incident boundary. If the
live tool schemas lack `incident_timing`, explain the missing capability instead
of inventing a tool or storing a boundary as an evidence timestamp.

1. Read the investigation with `investigation_get`: kind, lifecycle, current
   version and both reported instants. Use only supported source times resolved
   to RFC 3339 UTC ending in `Z`. Missing dates, offsets or boundaries stay unknown;
   ask when they prevent the requested edit. Notification, registration,
   resolution and a single successful probe do not establish incident boundaries.
2. Use `investigation_update` with `body.expected_version` and the complete
   intended `body.incident_timing`. That object replaces the previous timing
   object. Preserve an existing start when changing recovery, and vice versa.
   Omitting the whole object preserves it; `{}` clears both instants. To clear
   only recovery, retain the known `started_at` and omit `recovered_at`. Do not
   send null or empty strings. Clear values only within the user's request.
3. Keep unrelated investigation fields and lifecycle unchanged. On a version
   conflict, retain the requested edit, read the new investigation and reconcile
   its current timing before using its version. Ask if competing source values
   require a choice; do not just replace the precondition in the old body.
   Use only retry parameters advertised by the live tool. After an uncertain
   response, read back before repeating the update.
4. Read back both instants and the investigation version. Correct and recheck
   omissions within scope, or report incomplete verification. Time to recovery
   is recovery minus start only when both are known and ordered; zero is valid.
   It is not MTTR, and no duration field is submitted. Saving timing does not
   confirm a cause or resolve an incident.

A saved handover retains its captured timing. Read its exact snapshot when
summarizing it; do not substitute later investigation times. A new handover or
report requires the corresponding request. See the
[partial-update example](request-examples.md#record-incident-recovery-without-clearing-its-start).

## Known local time

Supplied observation: "14 October 2026 at 19:41, Europe/Stockholm: 441 active
connections waiting for relation locks." The source or user established the
timezone. Stockholm uses UTC+02:00 on this date, so the occurrence is 17:41Z.
Use IANA timezone conversion, including daylight-saving rules for the date.
Clock precision to the minute does not establish second-level measurement.

```json
{
  "schema_version": "2.0",
  "title": "Database: 441 connections waiting for relation locks",
  "raw_text": "14 October 2026 at 19:41, Europe/Stockholm: 441 active connections waiting for relation locks.",
  "capture_channel": "mcp",
  "event_time_start": "2026-10-14T17:41:00Z",
  "event_time_end": null,
  "time_precision": "exact",
  "original_time_text": "14 October 2026 at 19:41",
  "original_timezone": "Europe/Stockholm",
  "limitations": ["Reported observation, precise to the minute; underlying metrics have not been independently queried."]
}
```

If the source says "around 19:41", keep the same supported anchor with
`time_precision: approximate` and preserve "around" in `original_time_text`.
If it supplies a measured 19:41–19:44 interval on that date, set the end to
`2026-10-14T17:44:00Z` and precision to `interval`. A query window is not
automatically the period during which the symptom occurred.

## Message time without occurrence time

"We previously saw database locks" posted on 19 October does not date the locks.
Preserve the actual message time in `report.sent_at` using its live schema and
retain the source reference. Use null occurrence fields, `time_precision: unknown`
and explain the missing event date/time. `observed_at` is appropriate when the
source reports the observation time or the collector records it during direct
observation. Neither field fixes an unknown occurrence time. In a daylight-saving overlap, an IANA zone and local
clock alone may still be ambiguous; obtain the offset or retain uncertainty.

For example, if a dashboard shows an event window of 09:10–09:25 UTC and an
operator reports viewing it at 09:31 UTC, record the window as occurrence time
and 09:31 as `observed_at`. If the viewing time was not supplied, do not infer it
from submission or registration time.

## Reports containing several events

Keep the original report and exact received queries/results. When chronology
requires separate milestones, capture clearly labeled excerpts for the distinct
observations, each with its own supported time and provenance. Use exact parent
references through the live `references` schema where supported. Do not copy the
report's publication time onto every milestone or duplicate an existing capture.

## Corrections and verification

Read the current evidence revision before correcting times. Preserve raw text,
operations, files, source roles, limitations and unrelated fields. Supply the
expected revision and explain the time correction. Review the new revision before
deliberately updating a finding's exact evidence reference; never silently retarget
an assessment across a substantive change.

After a successful write, inspect the returned evidence fields and event-time
Timeline, including later pages when needed. Verify the latest revision appears
at the expected time; an unknown occurrence remains explicitly unknown. If this
read fails, say the save succeeded but chronology verification is incomplete.
