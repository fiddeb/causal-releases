# Occurrence time and chronology

Read the live schema. Time fields belong to evidence: directly in
`evidence_submit.body`, inside `capture_submit.body.evidence`, or in the revised
evidence payload. Findings link exact evidence revisions; they do not supply an
independent occurrence timestamp.

## Known local time

Supplied observation: "14 October 2026 at 19:41, Europe/Stockholm: 441 active
connections waiting for relation locks." The source or user established the
timezone. Stockholm uses UTC+02:00 on this date, so the occurrence is 17:41Z.
Use IANA timezone conversion, including daylight-saving rules for the date.
Clock precision to the minute does not establish second-level measurement.

```json
{
  "schema_version": "2.0",
  "title": "Database: 441 connections waiting for relation locks",
  "raw_text": "14 October 2026 at 19:41, Europe/Stockholm: 441 active connections waiting for relation locks.",
  "capture_channel": "mcp",
  "event_time_start": "2026-10-14T17:41:00Z",
  "event_time_end": null,
  "time_precision": "exact",
  "original_time_text": "14 October 2026 at 19:41",
  "original_timezone": "Europe/Stockholm",
  "limitations": ["Reported observation, precise to the minute; underlying metrics have not been independently queried."]
}
```

If the source says "around 19:41", keep the same supported anchor with
`time_precision: approximate` and preserve "around" in `original_time_text`.
If it supplies a measured 19:41–19:44 interval on that date, set the end to
`2026-10-14T17:44:00Z` and precision to `interval`. A query window is not
automatically the period during which the symptom occurred.

## Message time without occurrence time

"We previously saw database locks" posted on 19 October does not date the locks.
Preserve the actual message time in `report.sent_at` using its live schema and
retain the source reference. Use null occurrence fields, `time_precision: unknown`
and explain the missing event date/time. `observed_at` is appropriate only when
the source actually establishes when observation occurred. Neither field fixes
an unknown occurrence time. In a daylight-saving overlap, an IANA zone and local
clock alone may still be ambiguous; obtain the offset or retain uncertainty.

## Reports containing several events

Keep the original report and exact received queries/results. When chronology
requires separate milestones, capture clearly labeled excerpts for the distinct
observations, each with its own supported time and provenance. Use exact parent
references through the live `references` schema where supported. Do not copy the
report's publication time onto every milestone or duplicate an existing capture.

## Corrections and verification

Read the current evidence revision before correcting times. Preserve raw text,
operations, files, source roles, limitations and unrelated fields. Supply the
expected revision and explain the time correction. Review the new revision before
deliberately updating a finding's exact evidence reference; never silently retarget
an assessment across a substantive change.

After a successful write, inspect the returned evidence fields and event-time
Timeline, including later pages when needed. Verify the latest revision appears
at the expected time; an unknown occurrence remains explicitly unknown. If this
read fails, say the save succeeded but chronology verification is incomplete.
