# Practice: latency improves, cause remains unknown

All names, measurements and events below are synthetic training data. This is a
reading and reasoning exercise, not an import bundle or the built-in checkout
demo. It needs no live service, database, telemetry connection or command execution.

## Run the exercise

Work through one round at a time. After each round, state what is known, what
remains uncertain and which check would best distinguish the current explanations.
For an agent-led session, provide only the current and earlier rounds to the
participant. Keep the review rubric for the debrief.

Suggested request:

> Use the Causal investigation skill to work through round 1 of the synthetic
> latency exercise. Propose a prediction and next check. Discuss only the supplied
> observations; do not save records or run commands. Wait for the next round.

Saving is optional and requires an explicit request selecting a disposable
practice workspace and investigation. If saving, use the live tool schemas,
preserve the synthetic label and record known occurrence times. The labels E1-E7
below are exercise references, not server IDs. Link the exact revisions actually
returned by Causal; never submit these labels as IDs or invent reference values.
Do not mix this case into a real incident or silently select the default workspace.

## Round 1: a plausible explanation

Date: 2026-10-20. All times are UTC. Scope: the fictional `docs-preview` service
in `training-eu-1`. No real customer impact is asserted.

**E1, 10:00-10:15:** A synthetic probe reports dynamic-page p95 of 1,100 ms,
compared with 140 ms in the preceding 15 minutes. Request volume is approximately
100 requests/s in both windows. No static-resource measurements are supplied yet.

**E2, 10:00-10:15:** A supplied telemetry excerpt reports that datastore
`merge_scan` calls increased from 20 to 80 calls/s during the same interval.
The excerpt supplies no query plans, per-call latency or request-level attribution.

Proposed finding: "Slow datastore query plans explain all of the new response
latency." It is a suspicion, not a confirmed cause.

Participant task: describe what that claim predicts. Choose a comparison that
could distinguish datastore query time from work elsewhere in request handling.
Record what would weaken the claim as well as what might support it.

## Round 2: two checks that do not settle it

**E3, check at 10:18:** A reported log search returns zero matches. It searched
09:40-09:45, before the observed degradation, and only one application instance.
Its filter was `level=error`. No incident-window log search has been supplied.

**E4, 10:19:** A database connection attempt from an engineer's workstation
times out. The workstation uses a different network and identity from the
application. No corresponding check from an affected application instance is
available. This attempt does not report datastore query timings.

Participant task: explain whether either result should support or contradict
the proposed finding. Preserve the checks and their limits. Do not claim that
the service had no errors or that its database connection failed.

## Round 3: evidence challenges the explanation

**E5, 10:21-10:24:** A supplied comparison uses the same synthetic probe, target
application instance and interval. Dynamic-page p95 is 1,080 ms. Static-resource
p95 is 970 ms, compared with a supplied earlier baseline of 35 ms.

The accompanying request-path note says static resources are served by this
application process, through shared tenant middleware, without a datastore call.
Sampled static-request traces show no datastore spans. The traces do not cover
every request and contain no application CPU profile.

Participant task: revise the assessment of the claim that query plans explain
all new latency. Explain the relevant request-path assumption and coverage limit.
Do not infer a confirmed middleware or CPU cause from the missing profile.

## Round 4: recovery without an isolated mechanism

**E6, change at 10:27:** The operator reports switching the service to a larger
instance class. CPU and memory limits both increased and application processes
restarted. There is no isolated CPU-only comparison, before-change profile or
reported rollback test. No code release was reported during this change.

**E7, 10:30-10:40:** Supplied probes report dynamic-page p95 of 160 ms and
static-resource p95 of 40 ms at approximately 100 requests/s. `merge_scan` calls
remain near 80 calls/s. The operator reports that the exercise can continue with
this resource allocation. No later recovery measurements are supplied.

Participant task: prepare a short handover separating the intervention, observed
recovery, assessment changes and remaining questions. If closure is explicitly
requested, consider `mitigated` with cause status `unknown`; recovery does not
require manufacturing a confirmed finding.

## Review rubric

Review the reasoning after the participant has completed the rounds. Alternative
next checks are valid when they distinguish explanations and state their limits.

| Check | Evidence of a useful result |
| --- | --- |
| Testable prediction | The plan distinguishes datastore-dependent requests from another path, or offers another justified comparison with expected outcomes. |
| Honest negative results | E3 and E4 remain available with their time, coverage and execution-context limits. Neither becomes proof about the incident's application behavior. |
| Revised assessment | E5 challenges the complete datastore-only explanation. The revision retains E2 and explains why correlation alone was insufficient. |
| Bounded inference | The participant does not claim all database involvement is disproved. Shared effects and unobserved request paths remain possible. |
| Intervention fidelity | The handover names CPU, memory and restart together. It does not describe E6 as a controlled CPU-only experiment. |
| Recovery and uncertainty | E7 supports reported recovery within its interval, not a confirmed underlying mechanism. The cause remains unknown. |
| Record integrity, if saved | Earlier assessments remain readable; links use actual exact revisions; event times retain UTC and their supplied ranges. |
| Useful continuation | The next step targets a remaining distinction, such as profiling pre-RPC work if the symptom recurs, rather than repeating an unsuitable check. |

A suitable final handover could read:

> Synthetic docs-preview latency recovered during 10:30-10:40 UTC after an
> instance-class change increased CPU and memory and restarted the processes.
> Both dynamic and static requests had slowed. The supplied static path does
> not call the datastore, challenging the initial query-plan explanation for
> all latency. Higher datastore call volume persisted after recovery. The log
> search covered an earlier window; the workstation timeout did not test the
> application context. Root cause remains unknown. If the symptom recurs,
> collect an application profile and comparable request traces before another
> intervention when operationally appropriate. The exercise contains no such
> profile or isolated resource comparison.

When saving this handover, attach the actual evidence/finding references and
review the current State basis first. Do not claim this sample prose is already
stored, that a proposed follow-up ran, or that the exercise validates real systems.
