# Synthetic reporting examples

All services, dates, values, counts and URLs in this file are fictional.
The scenarios are illustrative and do not reproduce an actual investigation.
The example.invalid domains are placeholders, not sources that were inspected.

## Contents

- Repeated alerts
- Relative-time dashboard
- Live sample API
- Ticket or chat comment
- Current configuration and code
- Error targets and temporary views
- Precise relations

## Repeated alerts

**Title:** Cedar: repeated queue-depth alerts

**Summary:** The checked sample contains eight firing and three resolved
notifications on 8 April 2032, 09:10–09:35 UTC. Unique incident count and actual
queue depth are not established. The source reports an alert condition; it
does not establish the initiating cause or service recovery.

**Source label:** Representative original notification, 8 April 2032.

Illustrative location: https://chat.example.invalid/messages/fictional-alert

Preserve the checked message identities and source material in real evidence
details. If message authors or relays differ, keep their provenance separate.
Do not treat eleven notifications as eleven incidents.

## Relative-time dashboard

Illustrative location:
https://dashboard.example.invalid/d/sample-latency?from=now-2h&to=now

This URL changes the viewed period on later visits. Suppose the supplied
fictional observation concerns 8 April 2032, 09:10–09:35 UTC and the supplied
comparison concerns 08:30–09:00 UTC.

**Title:** Quartz API: median latency reached 240 ms

**Summary:** Quartz API median response time reached 240 ms on 8 April 2032,
09:10–09:35 UTC, compared with 35 ms during 08:30–09:00 UTC that day. The
initiating cause is unverified.

The actual card must include the date, absolute intervals and timezone in
accessible context. Store the relevant datasource, filters, aggregation and
result in details. Use a supported absolute-time link if available. Neither
fixed URL parameters nor a constant dashboard ID freeze retained data,
recording rules or alert evaluations.

Do not infer a percentile from an unrelated latency gauge or invent a
comparison period when the source does not supply one.

## Live sample API

Illustrative location:
https://samples.example.invalid/api/records?limit=250

**Title:** Larch: 46% of records in the inspected export

**Summary:** Larch accounts for 46% of records in the inspected export.
The capture period is unknown, so this share cannot be assigned to the
interruption. The count describes exported records, not request rate.

Details should preserve the actual population, denominator, response,
pagination, collection time and export identity when known.
Export creation time and process uptime do not establish capture bounds.
Aggregated attribute estimates across several services do not automatically
describe one service's attributes or generated metric labels.

## Ticket or chat comment

Illustrative location:
https://tickets.example.invalid/browse/DEMO-208?comment=sample-note

**Source label:** Support note reporting failed requests on 8 April 2032.

Summarize the relevant observation and known message time in the card.
Record current workflow status separately with its inspection time if useful.
An unread attachment is a gap, not a basis for inference. Use an exact
comment/message link when available without treating mutable text as immutable.

## Current configuration and code

A repository version or current configuration can establish what was read
from that version or object. It does not by itself establish what ran during
an interruption. Keep intended config, effective runtime config and software
defaults separate. Use a commit reference when available; do not invent a
historical deployment revision.

## Error targets and temporary views

A readiness or delivery URL inside an error identifies the attempted target.
Preserve it literally in the error and explain its role. Link the log/event
source separately; the target is not necessarily an evidence-view page.

For a temporary registry view, preserve the time and observed result.
Label it temporary/live. A later visit need not reproduce the saved observation.

## Precise relations

A traffic measurement can support the claim that an exporter contributed load
while weakening the narrower claim that a new traffic surge preceded failures.
Explain those propositions separately. If the capacity limit is unknown,
do not conclude that all saturation explanations have been rejected.

A report restating a measurement is not an independent second confirmation.
When assessment writes are in scope, update the existing assessment to identify
what the new evidence settles and which test still distinguishes the remaining
explanations. Otherwise report the proposed assessment change without saving it.
