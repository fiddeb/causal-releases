# Plan a check and interpret its result

Use this guidance when the user asks to test a possible cause, interpret a result
or continue an investigation. Reuse the existing finding assessment and evidence
relations. These are prompts for reasoning, not mandatory capture fields.

## Start from the observation

Separate the expected behavior from the actual behavior. Retain supplied
reproduction conditions, affected scope and occurrence times. Missing baseline
or reproduction information remains unknown; it does not block saving a report.

For a suspected cause, consider what observation would be expected if it were
true, and which alternative explanation could produce the same observation.
Choose a useful next check that separates those explanations, considering
available access, likely causes and the operational risk of the check.

Example: both a network restriction and rejected database credentials could
explain a connection failure. A check from an unrelated workstation would not
establish what the affected application can reach. A proposed check should name
the relevant target and execution context, without inventing access or secrets.

## Use the existing fields

- `prediction`: expected observations and what different outcomes would mean.
- `next_test`: the proposed check and relevant comparison conditions.
- `test_outcome`: what was actually reported, with exact saved evidence revisions.
- `remaining_uncertainty`: missing coverage, alternative explanations and limits.

The prediction and next test describe a plan, not evidence that it ran. Preserve
the earlier plan when recording an outcome through a new finding revision.
If no useful check is known, retain uncertainty or mark the idea exploratory.
Do not create confidence percentages or automatically confirm a cause.

## Distinguish results that look negative

| Reported result | Interpretation to consider |
| --- | --- |
| No errors in an earlier five-minute log window | Does not establish absence during the incident. Retain the searched window and missing coverage. |
| A tool timed out before returning results | Records an unsuccessful observation attempt, not a negative observation of the target system. |
| A connection failed from a workstation | Does not establish failure from the affected application's network or identity. |
| An expected effect is absent in a relevant, adequately observed comparison | May contradict the specific prediction. Explain the scope and remaining alternatives. |

Use `context` if the observation's bearing on a finding is unresolved. A
`contradicts` relation needs an explanation of which claim the observation
challenges. It need not disprove every contributing factor. Keep useful negative
and inconclusive results available in the investigation and handover so others
can see what was tried and avoid repeating it without a reason.

## Record interventions without overstating cause

For a reported active test or mitigation, preserve the supplied change, timing,
before/after observations, concurrent changes, possible side effects and rollback
or restoration details. Leave missing details unknown. Do not silently treat
different environments, identities, workloads or resource settings as equivalent.

Recovery after an intervention is an observation. It may support a mechanism,
but it does not isolate that mechanism by itself. A mitigated investigation may
retain an unknown root cause and concrete follow-up questions. Causal records
the user's or client's assessment; it does not execute the check or certify it.

## Practice and source

The [latency exercise](latency-exercise.md) provides staged synthetic evidence
and a review rubric using these fields. It includes a misleading correlation,
inconclusive checks and recovery without an established cause.

Methodological background: Google SRE, [Effective Troubleshooting](https://sre.google/sre-book/effective-troubleshooting/),
especially Test and Treat and Negative Results Are Magic. The examples here are
original Causal training material; they are not reports about Google's systems.

## Applying relations and answered checks

Apply each relation to a precise proposition with compatible scope and period.
Explain what it supports or weakens and which causal link remains unverified.
A report and the measurement it repeats are not independent confirmations. When
new evidence answers a stored test, review `prediction`, `next_test` and
`test_outcome`; revise the assessment only when that write is in scope. Otherwise
identify the answered test and remaining question in the response.
