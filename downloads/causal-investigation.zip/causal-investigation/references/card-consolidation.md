# Review duplicate and overlapping cards

Use this workflow when the user asks to review or consolidate cards in one
investigation. Discovery is read-only. Similar wording does not establish that
observations or assessments are duplicates.

## Contents

- Establish coverage
- Present concrete proposals
- Preview, confirm and report

## Establish coverage

Discover `cards_review_inventory`, `cards_consolidate_preview` and
`cards_consolidate` in the live tool schemas. If unavailable, explain that this
server version lacks consolidation; do not approximate it by deleting evidence,
emptying source cards or reclassifying duplicates as false findings.

Read the investigation, then request its inventory with `investigation`. Follow
all `next_cursor` pages with the same filters and record the `basis_seq`. Default
inventory excludes already consolidated sources; use `include_consolidated`
when the task includes their history. Report the number of evidence and finding
cards reviewed and any incomplete pages or unread attachments. Entries contain
bounded excerpts and an explicit truncation flag. Even an untruncated excerpt
omits operations, source metadata and assessment fields.

Use inventory text to select candidate groups. Read complete exact candidates
with `evidence_revision_get` or `finding_revision_get`; retrieve relevant file
content and all response parts. Compare original source identity, occurrence
time/window, environment, entity, measurements, claims and uncertainty. Repeated
alerts at different times or matching observations from independent sources may
be valuable separate evidence. Overlapping content may justify a shared account,
but should not erase contradictory or independent observations.

Distinguish inventory coverage from full-content review. Do not claim that all
cards were fully reviewed unless every full card and relevant attachment was
actually read. Explain when short excerpts limit candidate discovery.

## Present concrete proposals

For each proposed group show:

- Same card kind, exact member references and the selected existing primary.
- Why they appear duplicate or overlapping, plus source/time/scope differences.
- The proposed combined title/summary for evidence, or complete finding content
  including classification, rationale, assessment, critical status and relations.
- Unresolved differences and why distinct observations should remain separate.

Evidence consolidation changes only the primary's title and summary. Its raw
payload stays unchanged; source observations, operations and attachments remain
on original cards, linked from the primary. Do not promise that all source fields
or images will be copied into one payload.

For findings, retain every member's exact evidence relations and their rationales,
including contradictions. Reconcile test plans/results, classifications, critical
status, prior work and improvement fields explicitly. Repetition does not increase
causal confidence. Source revisions retain other original fields, but omitted
fields will not appear in the new primary payload. Surface such choices for review.

Obtain approval of concrete groups and their proposed content before confirmation.
Existing explicit approval of those same groups is sufficient. A request to find
duplicates alone does not authorize consolidation. A mixed evidence/finding group
must be split; similarity alone does not authorize creating a new finding or State.

## Preview, confirm and report

Call `cards_consolidate_preview` with `investigation` and `body`:

```json
{
  "kind": "evidence",
  "primary": {"id": "PRIMARY_UUID", "revision": 2},
  "sources": [{"id": "SOURCE_UUID", "revision": 1}],
  "reason": "Same reported observation; preserve source differences",
  "evidence_title": "Reviewed combined title",
  "evidence_summary": "Reviewed account with uncertainty and source differences."
}
```

For findings, send `kind: "finding"` and `finding: COMPLETE_FINDING_PAYLOAD`
instead of the two evidence text fields. One group supports up to 50 sources in
one active investigation. Do not silently split a larger group: each commit would
change its primary revision and needs its own reviewed preview.

Read the returned original members and proposed payload, including all byte
parts. Verify they match the approved proposal. Confirm with the same authenticated
principal using `cards_consolidate`, an idempotency key and:

```json
{
  "preview": {
    "kind": "evidence",
    "primary": {"id": "PRIMARY_UUID", "revision": 2},
    "sources": [{"id": "SOURCE_UUID", "revision": 1}],
    "reason": "Same reported observation; preserve source differences",
    "evidence_title": "Reviewed combined title",
    "evidence_summary": "Reviewed account with uncertainty and source differences."
  },
  "scope_digest": "digest returned by the preview",
  "confirm": true
}
```

Replace example IDs and the digest with returned values. Apply each approved group separately
and report partial batch progress if a later group fails. Retry uncertain writes
with the same body/key according to the main skill's retry rule. A stale revision
or digest requires new reads and preview; do not replace concurrency numbers and
blindly repeat. Reuse existing approval only when content and the decision remain
unchanged. Never reopen an investigation just to bypass its lifecycle error.

Report the returned primary and source revisions. Originals are hidden from
ordinary lists, retained in history, and available with `include_consolidated=true`.
Old citations remain exact; never retarget them automatically. A primary may later
be consolidated into another primary, preserving the chain. Consolidation makes
Current State stale; refreshing it is separate work requiring the user's scope.
