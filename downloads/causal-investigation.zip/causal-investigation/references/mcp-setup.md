# Set up the local Causal MCP connection

Use this procedure when the user requests installation, configuration or repair.
Ordinary investigation access does not authorize changing client configuration.
Preserve existing servers, credentials, custom workspace selection and local edits.

## 1. Inspect the installation and workspace

Find the installed executable with `command -v causal`; run its `--version` and
`mcp --help`. If installation is requested and Causal is missing on a supported
Apple Silicon Mac, use `brew install fiddeb/tap/causal`. Follow the public release
instructions for other supported installation methods; do not build from private
source as an implicit prerequisite.

Determine whether the requested workspace is already running. The default is
`~/Library/Application Support/Causal` at `http://127.0.0.1:7432`. Ask which
workspace to use if existing configuration leaves a material choice unresolved.
Do not initialize another workspace to work around a connection or key error.

## 2. Start the HTTP service

If needed, start the selected workspace and keep its process running:

```sh
causal serve
```

For authorized startup without a browser use `causal serve --no-open`. For a
custom workspace, use its actual absolute path with `serve --data-dir PATH`;
an alternative loopback listener uses `--listen 127.0.0.1:PORT`. Avoid starting a
second process on an occupied port; first identify the existing instance.
No background service installation is required.

## 3. Register the stdio adapter in the agent client

The client starts `causal mcp`, which talks to the running HTTP service. Do not
register `causal serve` as the MCP command and do not register port 7432 as an
HTTP MCP endpoint. It is the application API, not an MCP transport.

For Codex, inspect `codex mcp list` and the existing `causal` entry before edits.
For a new connection on a standard Apple Silicon Homebrew installation:

```sh
codex mcp add causal -- /opt/homebrew/bin/causal mcp
codex mcp list
```

Substitute the absolute path discovered in step 1. GUI clients may not inherit
the terminal's PATH. If editing Codex configuration instead, merge this table
into the user's existing configuration without replacing other entries:

```toml
[mcp_servers.causal]
command = "/opt/homebrew/bin/causal"
args = ["mcp"]
```

Other MCP clients need the same stdio executable and argument array in their
documented configuration format. A client must run locally where it can execute
the binary and reach the selected loopback service; a remote-only host cannot
reach the user's Mac through its own localhost.

The adapter automatically reads the default local credential file. For a custom
workspace or a separately issued client credential, set non-secret file paths and
the matching API URL explicitly. Example Codex arguments, replacing placeholders:

```toml
[mcp_servers.causal]
command = "/absolute/path/to/causal"
args = ["mcp", "--api-url", "http://127.0.0.1:7432", "--key-file", "/absolute/workspace/keys/client.key"]
```

Use an existing appropriate private key file; `owner.key` is the default local
owner credential, while a separately issued client key can restrict access.
Never read a secret into chat, put its value in config/arguments/URLs, or replace
credentials on failure. This stdio adapter uses local file authentication, not
`codex mcp login` or an OAuth flow. Do not weaken permissions to make it connect.

## 4. Reconnect and verify without writes

Reconnect or restart the MCP connection in the client after configuration or
binary upgrades. Rediscover live tool schemas and call `investigations_list`
with a small limit. An empty list is a valid successful response. Verify the
selected workspace with the user-provided investigation context before writing.
Do not create a demo investigation as a connection test.

For `server_unavailable`, check the running service and matching loopback URL.
For missing credentials or authorization failure, check the selected file path
and credential scope without displaying the secret. Keep protocol stdout clean;
diagnostics belong on stderr. Report any remaining failure with the safe error
code and which setup step failed.

Codex syntax and configuration reference: [official MCP documentation](https://developers.openai.com/codex/mcp).
