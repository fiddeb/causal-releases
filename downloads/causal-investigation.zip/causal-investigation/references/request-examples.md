# MCP request examples

Inspect the active tool schema before sending a request. Replace illustrative
UUIDs with IDs returned by the current workspace and use a new idempotency key
for each new logical write. Keep the same key and unchanged arguments only for
retrying that write. The examples below are not instructions to mutate data.
These JSON objects show internal MCP requests. Do not paste them into an
operator update or handover; explain the result in plain language and provide
the relevant Causal reference for detail.

## Contents

- Find active investigations
- Record supplied evidence
- Preserve terminal output and code layout
- Capture a symptom atomically
- Update an observation without another card
- Create the first Current State
- Save a fixed handover
- Read a complete exact card

## Find active investigations

Tool: `investigations_list`

```json
{"status":"active","q":"gateway","limit":20}
```

Follow `next_cursor` with the same filters when more matches are needed.
Read the selected investigation before writing; its title alone is not an ID.

## Record supplied evidence

Tool: `evidence_submit`

```json
{
  "investigation":"0196b900-0000-7000-8000-000000000001",
  "idempotency_key":"capture-example-unique-request",
  "body":{
    "schema_version":"2.0",
    "title":"Gateway latency increased after deployment",
    "raw_text":"Gateway latency increased after deployment.",
    "capture_channel":"mcp",
    "event_time_start":null,
    "event_time_end":null,
    "time_precision":"unknown",
    "limitations":["Supplied text; producer, event time and original source are unknown."]
  }
}
```

Use this minimal shape when only pasted text is known. Add actual attribution,
source, operations and timestamps when supplied; do not fill them with guesses.
The response identifies the stored evidence and revision. Inspect that response
before linking the evidence elsewhere. Do not copy an illustrative UUID or a
client-generated timestamp into a server-owned field.

## Preserve terminal output and code layout

Longer text fields accept literal Markdown backtick fences with an optional
language tag. For example, send this string as `raw_text` through REST or MCP:

````text
Reported pod configuration:

```yaml
spec:
  containers:
    - name: gateway
      image: gateway:reported-version
```
````

Use actual newlines in text, or JSON `\n` escapes inside JSON string values.
The UI renders complete fenced blocks without line wrapping and retains the
submitted string unchanged. A language tag is a display hint, not proof that a
command was executed or a configuration was applied. Choose `text` or `bash`
for terminal output when appropriate. Longer fences can contain shorter fences.

## Capture a symptom atomically

Tool: `capture_submit`

```json
{
  "investigation":"0196b900-0000-7000-8000-000000000001",
  "idempotency_key":"symptom-example-unique-request",
  "body":{
    "evidence":{
      "schema_version":"2.0",
      "title":"Gateway latency increased after deployment",
      "raw_text":"14 October 2026 at 19:41 Europe/Stockholm: gateway latency increased after deployment.",
      "capture_channel":"mcp",
      "event_time_start":"2026-10-14T17:41:00Z",
      "event_time_end":null,
      "time_precision":"exact",
      "original_time_text":"14 October 2026 at 19:41",
      "original_timezone":"Europe/Stockholm",
      "limitations":["Reported observation; deployment causality has not been established."]
    },
    "finding":{
      "classification":"symptom",
      "statement":"Gateway latency increased",
      "rationale":"Elevated latency was reported after deployment; the temporal relationship does not establish cause."
    }
  }
}
```

The illustrative source explicitly supplies the date and timezone; the time is
precise to the minute. Do not reuse it for actual captures. Inspect saved evidence
and `timeline_list` with `order: event_time` after saving. See
[time examples](timestamps.md) for ranges and unresolved times.

This saves evidence and its initial finding together. It does not classify the
deployment as a confirmed cause. When assessing stored evidence, first read
relevant existing findings. Use `finding_revise` for an existing claim, retaining
exact evidence relations; use `finding_create` only for a distinct new claim.
Do not capture the same evidence again.

## Update an observation without another card

Synthetic input: "The queue-depth observation on evidence E1 was viewed at
09:31 UTC on 8 April 2032. Add that detail to E1. The event window remains
09:10–09:25 UTC. Review its relationship to the existing worker-capacity finding."

Read E1 and the relevant finding, resolve their actual server IDs and revisions,
then use `evidence_revise` with the supported `observed_at` and a reason. Retain
the event window and original material. Read back both kinds of time and check
Timeline. Reassess the finding's relation to the new exact evidence revision;
a corrected viewing time alone does not strengthen causal support.

After verified success, a useful answer is: "Updated the queue-depth observation
with the viewing time, 09:31 UTC. The event window is still 09:10–09:25 UTC.
This adds timing context but does not strengthen the worker-capacity explanation."
Append the relevant Causal reference. E1 is an exercise label, never a tool ID.

## Create the first Current State

Tool: `state_update`

```json
{
  "investigation":"0196b900-0000-7000-8000-000000000001",
  "idempotency_key":"state-example-unique-request",
  "body":{
    "expected_revision":0,
    "basis_seq":7,
    "known_facts":[{"text":"Latency was reported; the original event time is unknown."}],
    "remaining_uncertainty":[{"text":"The relationship to deployment is unverified."}],
    "next_steps":[{"text":"Compare deployment and latency evidence using the authorized external tools."}]
  }
}
```

`0` is valid only for the first State. Replace `7` with the actual sequence whose
relevant changes were reviewed. For an existing State, preserve all unrelated
entries and use its actual revision. Add exact evidence/finding references using
the live StateEntry schema when available. Next-step ownership must be supplied
or known; do not assign an invented person.

## Save a fixed handover

Tool: `handover_create`

```json
{
  "investigation":"0196b900-0000-7000-8000-000000000001",
  "idempotency_key":"handover-example-unique-request",
  "body":{}
}
```

Read the returned snapshot before authoring a report. A report variant uses the
same tool with `body.base_handover_id`, `audience`, `language`, `report_text` and
supported structured `claims`. Use the returned base ID, not a newly guessed ID.
Do not silently refresh State or change classifications just to create a handover.

## Read a complete exact card

Tool: `card_get_complete`

```json
{
  "investigation":"0196b900-0000-7000-8000-000000000001",
  "type":"evidence",
  "id":"0196b900-0000-7000-8000-000000000002",
  "revision":1,
  "format":"json"
}
```

Use the actual referenced revision. Investigation cards require `version`;
evidence, finding and State cards require `revision`. Timeline events and
handovers are immutable. Follow byte-part continuations before treating the
result as complete. A list preview is not a substitute for this exact read.
