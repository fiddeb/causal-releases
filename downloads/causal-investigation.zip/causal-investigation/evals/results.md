# Causal investigation skill evaluations

Date: 2026-10-25. Tested model: gpt-6-astra, inherited from the coordinating
session. The worker identified itself as GPT-6 without exposing the variant.
Other models have not been evaluated against this revision.

## Method and limits

A fresh agent read the skill and relevant references, then received the four
synthetic requests and inputs from `evals.json` with expected behaviors removed.
It returned proposed tool operations and user-facing answers. The coordinating
agent graded every expected behavior against that output. No live service or
investigation was accessed; write outcomes were simulated only where supplied.
The four cases shared one fresh context. No without-skill baseline was run.
These results establish bounded reasoning coverage, not successful live writes
or reliable behavior across every model and request.

## Task results

| Scenario | Criteria met | Observed behavior |
| --- | --- | --- |
| observation-update | 5/5 | Revised E1, detected null observation time in simulated revision 4, corrected and verified revision 5, preserved the event window, and reviewed F1 without strengthening its causal claim. |
| existing-finding-connection | 5/5 | Proposed distinct evidence and revisions to F2/F3; challenged the datastore-only claim, kept shared-bottleneck support tentative, and kept collection time separate from unknown observation time. |
| ambiguous-existing-observation | 3/3 | Asked which card and which viewing date/timezone; made no write and created no card. |
| operator-status | 4/4 | Produced a concise update with bounded recovery, unknown cause, rollback, the earlier search's limit and a next check; omitted internal metadata and performed no writes. |

The first case's answer began: "Updated the queue observation with the viewing
time: 8 April 2032 at 09:31 UTC. Verified that the event window remains
09:10–09:25 UTC." It then retained the suspected capacity classification.
This success statement was justified only by the supplied simulated outcome.

The ambiguous case answered: "Which observation should I update: production on
8 April 2032, or staging on 9 April 2032? What date and timezone does the 09:31
viewing time refer to? I haven't changed either card."

The status answer was:

> Synthetic checkout is showing recovery: after the 09:28 UTC rollback, probes
> returned normal responses during 09:30–09:40 on 10 April. Errors had risen from
> 2% at 09:10 to 18% at 09:25. The cause remains unknown; a release link is
> suspected. The earlier log search covered only 08:50–08:55 and could not test
> the incident window. Next, compare failed requests from 09:10–09:25 with
> deployment changes.

## Description selection

The agent used the unchanged description to classify six requests. This tests
description interpretation, not a client's automatic skill discovery or ranking
against its complete installed catalog.

| Request | Expected | Selected | Result |
| --- | --- | --- | --- |
| Summarize my Causal investigation. | Yes | Yes | Pass |
| Save this observation to Causal. | Yes | Yes | Pass |
| Update the existing Causal finding with this result. | Yes | Yes | Pass |
| Implement a new Causal UI component. | No | No | Pass |
| Write a birthday message. | No | No | Pass |
| Format this standalone spreadsheet. | No | No | Pass |

## Review fixes covered

- C4: readback now checks observation time as well as event time, with correction
  and repeated verification. The omitted-time fixture exercises this loop.
- C5: the workflow table and request example both prefer revision of a relevant
  existing finding. Creation requires a distinct claim.
- S4: the four long references now have contents lists.
- S6: the main skill names host metadata and evaluation files.
- T1: four reusable cases define requests, synthetic inputs and expected behavior.
- C8: the request examples include an observation update and its readable answer.
- T2: this file records tested model coverage and its limits.

Generic Markdown fence instructions were shortened to keep the main skill at
its previous length while retaining literal layout, separate fences, longer
outer fences, source preservation and display behavior.

## Compact entrypoint follow-up

The earlier structure review was too generous about C1: the entrypoint repeated
reference material and loaded conditional procedures for every request. The
follow-up reduced the complete file from 347 to 90 lines and from 3,282 to 744
whitespace-separated words (77% fewer words). These are file measurements, not
an exact token count or a claim about total context for every workflow.

Detailed reads/writes and record authoring now have task-specific references;
time rules and causal reasoning reuse their existing references. The package
includes both new references. The description and authorization scope are unchanged.

A second fresh gpt-6-astra agent received the same four inputs without expected
behaviors or previous results. All 17 criteria passed again. It followed the
operations, timestamps, hypothesis-testing, record-writing and reporting links;
it did not load setup, request examples, consolidation, practice or evaluations.
The cases shared one fresh context, so this does not measure isolated per-task
context cost. Collection time and an ambiguous request to review a finding were
kept distinct from observation time and authorization to save an assessment.
No live writes were performed. Strict skill lint reported no errors or warnings.
