# Causal investigation skill evaluations

Date: 2026-10-25. Tested model: gpt-6-astra, inherited from the coordinating
session. The worker identified itself as GPT-6 without exposing the variant.
These historical results cover that skill revision. The incident timing follow-up
below records separate model and live-tool coverage.

## Contents

- Method and limits
- Task results
- Description selection
- Review fixes covered
- Compact entrypoint follow-up
- Incident timing follow-up (2026-11-05)

## Method and limits

A fresh agent read the skill and relevant references, then received the four
synthetic requests and inputs from `evals.json` with expected behaviors removed.
It returned proposed tool operations and user-facing answers. The coordinating
agent graded every expected behavior against that output. No live service or
investigation was accessed; write outcomes were simulated only where supplied.
The four cases shared one fresh context. No without-skill baseline was run.
These results establish bounded reasoning coverage, not successful live writes
or reliable behavior across every model and request.

## Task results

| Scenario | Criteria met | Observed behavior |
| --- | --- | --- |
| observation-update | 5/5 | Revised E1, detected null observation time in simulated revision 4, corrected and verified revision 5, preserved the event window, and reviewed F1 without strengthening its causal claim. |
| existing-finding-connection | 5/5 | Proposed distinct evidence and revisions to F2/F3; challenged the datastore-only claim, kept shared-bottleneck support tentative, and kept collection time separate from unknown observation time. |
| ambiguous-existing-observation | 3/3 | Asked which card and which viewing date/timezone; made no write and created no card. |
| operator-status | 4/4 | Produced a concise update with bounded recovery, unknown cause, rollback, the earlier search's limit and a next check; omitted internal metadata and performed no writes. |

The first case's answer began: "Updated the queue observation with the viewing
time: 8 April 2032 at 09:31 UTC. Verified that the event window remains
09:10–09:25 UTC." It then retained the suspected capacity classification.
This success statement was justified only by the supplied simulated outcome.

The ambiguous case answered: "Which observation should I update: production on
8 April 2032, or staging on 9 April 2032? What date and timezone does the 09:31
viewing time refer to? I haven't changed either card."

The status answer was:

> Synthetic checkout is showing recovery: after the 09:28 UTC rollback, probes
> returned normal responses during 09:30–09:40 on 10 April. Errors had risen from
> 2% at 09:10 to 18% at 09:25. The cause remains unknown; a release link is
> suspected. The earlier log search covered only 08:50–08:55 and could not test
> the incident window. Next, compare failed requests from 09:10–09:25 with
> deployment changes.

## Description selection

The agent used the unchanged description to classify six requests. This tests
description interpretation, not a client's automatic skill discovery or ranking
against its complete installed catalog.

| Request | Expected | Selected | Result |
| --- | --- | --- | --- |
| Summarize my Causal investigation. | Yes | Yes | Pass |
| Save this observation to Causal. | Yes | Yes | Pass |
| Update the existing Causal finding with this result. | Yes | Yes | Pass |
| Implement a new Causal UI component. | No | No | Pass |
| Write a birthday message. | No | No | Pass |
| Format this standalone spreadsheet. | No | No | Pass |

## Review fixes covered

- C4: readback now checks observation time as well as event time, with correction
  and repeated verification. The omitted-time fixture exercises this loop.
- C5: the workflow table and request example both prefer revision of a relevant
  existing finding. Creation requires a distinct claim.
- S4: the four long references now have contents lists.
- S6: the main skill names host metadata and evaluation files.
- T1: four reusable cases define requests, synthetic inputs and expected behavior.
- C8: the request examples include an observation update and its readable answer.
- T2: this file records tested model coverage and its limits.

Generic Markdown fence instructions were shortened to keep the main skill at
its previous length while retaining literal layout, separate fences, longer
outer fences, source preservation and display behavior.

## Compact entrypoint follow-up

The earlier structure review was too generous about C1: the entrypoint repeated
reference material and loaded conditional procedures for every request. The
follow-up reduced the complete file from 347 to 90 lines and from 3,282 to 744
whitespace-separated words (77% fewer words). These are file measurements, not
an exact token count or a claim about total context for every workflow.

Detailed reads/writes and record authoring now have task-specific references;
time rules and causal reasoning reuse their existing references. The package
includes both new references. The description and authorization scope are unchanged.

A second fresh gpt-6-astra agent received the same four inputs without expected
behaviors or previous results. All 17 criteria passed again. It followed the
operations, timestamps, hypothesis-testing, record-writing and reporting links;
it did not load setup, request examples, consolidation, practice or evaluations.
The cases shared one fresh context, so this does not measure isolated per-task
context cost. Collection time and an ambiguous request to review a finding were
kept distinct from observation time and authorization to save an assessment.
No live writes were performed. Strict skill lint reported no errors or warnings.

## Incident timing follow-up (2026-11-05)

The six incident scenarios added to `evals.json` were run against the published
Causal v0.0.11 binary through a temporary client using the official MCP Go SDK.
All records and source observations were synthetic. The service used a disposable
workspace, separate from the configured user connection. Runtime fixtures used
server-generated IDs and current versions rather than the illustrative versions
in `evals.json`. No credentials or live investigation data enter these fixtures.

A fresh Codex evaluator received the six requests without expected behaviors or
previous results. It read the skill, timestamps, tool operations and record-writing
references. Its exact model variant was not exposed. The coordinating agent graded
the output and independently read stored investigations and the exact handover.

| Scenario | Criteria met | Observed behavior |
| --- | --- | --- |
| incident-recovery-partial-update | 4/4 | Saved recovery, retained the reported start and unrelated fields, read back version 2 and reported 20 minutes without a lifecycle change. |
| incident-timing-version-conflict | 4/4 | A real concurrent fixture update corrected the start before the first write. After the rejected version, the evaluator re-read, preserved the corrected start and description, saved the requested recovery and verified 25 minutes at version 3. |
| incident-boundaries-unknown | 4/4 | Kept boundaries and duration unknown despite the alert and probe times; made no write. The first live fixture was active; the resolved variant was tested separately below. |
| incident-clear-recovery | 4/4 | Retained only the existing start, verified absent recovery and unknown duration, and preserved active status. |
| incident-clear-both | 4/4 | Explicitly cleared the timing object as requested, verified both unknown instants and retained unrelated fields and lifecycle. |
| incident-fixed-handover | 4/4 | Read the exact saved snapshot and reported its 10-minute interval while current investigation timing implied 20 minutes; made no write. |

Four intended updates committed. The conflict case added one rejected attempt.
The read-only cases made no mutations. Independent stored-state checks confirmed
the expected versions, both timing fields, unrelated descriptions, active status
and fixed handover contents.

### Named model and description selection

A separate fresh evaluator explicitly selected with `gpt-6.1-sol` first judged
the unchanged description without reading the skill body. All six selection
cases in the earlier Description selection table passed. This measures selection
judgment, not host-wide automatic discovery.

It then used the skill and live MCP schemas for another partial recovery update.
The stored start, new recovery, unrelated fields and active status were verified
by readback. Its short initial answer did not include the optional derived
duration. A separate read-only request for Time to recovery returned 20 minutes.
It also re-ran the unknown-boundary request after the fixture was marked resolved
with a reported recovery observation but no timing boundaries. It kept duration
unknown and made no write. No new cause, evidence, State or handover was created.

### Baseline and coverage limits

Before loading a skill, another fresh evaluator completed the partial-update
request against a separate live fixture. It preserved the start and verified
recovery and active status. Its user-facing answer omitted the derived duration,
so it met 3/4 of that scenario's reporting criteria while completing the requested
edit. Initial reads lacked sandbox localhost access; authorized retries through
the same credential-file-based connection succeeded before any mutation.

This single-case baseline does not establish a general improvement from the
skill. The six-case live run, the explicitly selected model run and the older
gpt-6-astra results have different scopes. The older results above cover their
recorded revision; gpt-6-astra was not re-run for this timing follow-up. No
cross-model compatibility or automatic-discovery guarantee is inferred.

### Validation

- Strict skill lint: no errors, warnings or info; entrypoint body is 87 lines.
- Skill creator validator: passed using its YAML dependency in a temporary environment.
- All seven fenced MCP request examples validate against the v0.0.11 catalog.
- Public archive scope and reproducibility tests: two passed.
- Guide build and browser checks passed, including responsive navigation, the
  installation page, actual skill download and its SHA-256 checksum.
- Independent static review found no required issue in replacement semantics,
  authorization, uncertainty, retries, conflicts or fixed-snapshot handling.
